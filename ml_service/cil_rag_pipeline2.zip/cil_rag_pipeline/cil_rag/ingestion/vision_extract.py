"""
Vision-based page extraction for scanned documents.

Why this exists: the reference document (SignedCILMoU2019-20.pdf) is a scanned
PDF -- every page is one raster JPEG with a broken embedded OCR text layer
(confirmed: pdftotext returns "Conl lrqon Lrrvutep" for "Coal India Limited").
Classical extraction (pdfplumber tables, pdftotext) has nothing usable to work
with here, so we skip OCR entirely and send each page image straight to
Gemini, asking it to return the page's structure as JSON in one call:
heading, narrative text, and any tables (with real column/row structure).

This does three jobs from the earlier discussion in a single API call:
  1. OCR replacement (reads the page image directly)
  2. Structure-aware chunk boundaries (heading + narrative vs table split)
  3. Table extraction into clean JSON (row/column alignment done by the model,
     which handles this scanned table's merged cells and skewed lines far
     better than clustering raw OCR bounding boxes would)
"""
import os
import json
import base64
import time
import random
from dataclasses import dataclass, field
from typing import Optional

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

GEMINI_MODEL_NAME = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

EXTRACTION_PROMPT = """You are extracting structured content from one page of a
scanned government document (a Coal India Limited / Ministry of Coal MoU).
The page image may contain typos from age/scan quality -- read the visual
content directly, do not rely on any invisible OCR text layer.

Return ONLY valid JSON (no markdown fences, no preamble) matching this shape:

{
  "page_number": <int, given below>,
  "section_heading": <string or null - the heading/annex title on this page>,
  "narrative_text": <string - any prose/paragraph text on the page, cleaned
                      up and correctly spelled; empty string if none>,
  "tables": [
    {
      "table_id": <string, e.g. "annex_ii_part_a">,
      "caption": <string or null - the table's own title/caption>,
      "columns": [<column names as they appear, flattened if multi-row headers>],
      "rows": [ {"<column>": "<value>", ...}, ... ],
      "notes": <string or null - footnotes below the table>
    }
  ],
  "signatories": [<string, only if this page has signature blocks with names/titles>]
}

Rules:
- Fix obvious OCR-style misreads using context (e.g. a scanned "Conl lrqon
  Lrrvutep" is "Coal India Limited") -- you are reading the image, not that
  broken layer.
- Preserve numbers exactly as shown. Do not round or reformat.
- If a table spans merged header cells (e.g. "MoU Target" spanning
  Excellent/V.G./Good/Fair/Poor), flatten each into its own column name,
  e.g. "MoU Target - Excellent".
- If the page has no tables, return an empty list for "tables".

Page number: <PAGE_NUMBER>
"""


@dataclass
class ExtractedTable:
    table_id: str
    caption: Optional[str]
    columns: list
    rows: list
    notes: Optional[str] = None


@dataclass
class ExtractedPage:
    page_number: int
    section_heading: Optional[str]
    narrative_text: str
    tables: list = field(default_factory=list)  # list[ExtractedTable]
    signatories: list = field(default_factory=list)


def _generate_with_retry(model, contents, max_retries: int = 4):
    """Same backoff pattern as agent.py's _generate_with_retry, reused here
    since ingestion will make many more Gemini calls (one per page) than the
    query side does, and is more likely to hit free-tier rate limits."""
    from google.api_core.exceptions import ResourceExhausted

    for attempt in range(max_retries):
        try:
            response = model.generate_content(
                contents,
                generation_config=genai.types.GenerationConfig(temperature=0.1),
            )
            return response.text
        except ResourceExhausted:
            if attempt == max_retries - 1:
                raise
            wait = (2 ** (attempt + 1)) + random.uniform(0, 1)
            print(f"  gemini 429, retrying in {wait:.1f}s (attempt {attempt+1}/{max_retries})...")
            time.sleep(wait)


def _parse_json_response(raw_text: str) -> dict:
    """Gemini sometimes wraps JSON in ```json fences despite instructions."""
    cleaned = raw_text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("```")[1]
        if cleaned.startswith("json"):
            cleaned = cleaned[4:]
    return json.loads(cleaned.strip())


def extract_page(image_path: str, page_number: int) -> ExtractedPage:
    """Send one rasterized page image to Gemini and parse the structured result.

    Requires GEMINI_API_KEY to be set. This is the one step in the ingestion
    pipeline that needs a live API call -- everything downstream (chunking,
    indexing) runs on its output and needs no further model calls per page.
    """
    if not GEMINI_API_KEY:
        raise RuntimeError(
            "GEMINI_API_KEY not set. This function needs a live Gemini call "
            "to run -- see mock_extract_page() for a offline stand-in used "
            "in tests/demos."
        )

    model = genai.GenerativeModel(GEMINI_MODEL_NAME)
    with open(image_path, "rb") as f:
        image_bytes = f.read()

    contents = [
        {"mime_type": "image/png", "data": image_bytes},
        EXTRACTION_PROMPT.replace("<PAGE_NUMBER>", str(page_number)),
    ]
    raw = _generate_with_retry(model, contents)
    data = _parse_json_response(raw)

    tables = [
        ExtractedTable(
            table_id=t.get("table_id", f"p{page_number}_t{i}"),
            caption=t.get("caption"),
            columns=t.get("columns", []),
            rows=t.get("rows", []),
            notes=t.get("notes"),
        )
        for i, t in enumerate(data.get("tables", []))
    ]
    return ExtractedPage(
        page_number=data.get("page_number", page_number),
        section_heading=data.get("section_heading"),
        narrative_text=data.get("narrative_text", ""),
        tables=tables,
        signatories=data.get("signatories", []),
    )
