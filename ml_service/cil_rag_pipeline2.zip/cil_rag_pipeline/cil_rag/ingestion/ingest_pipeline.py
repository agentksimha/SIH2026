"""
End-to-end ingestion: PDF -> rasterized pages -> Gemini vision extraction ->
chunks -> BM25 + structured indexes.

Usage with a real Gemini key:
    from ingestion.vision_extract import extract_page
    run_ingestion("SignedCILMoU2019-20.pdf", page_numbers=[2, 3, 18], extract_fn=extract_page)

Usage in this sandbox (no live API access):
    from ingestion.mock_extract import mock_extract_page
    run_ingestion("SignedCILMoU2019-20.pdf", page_numbers=[2, 3, 18], extract_fn=mock_extract_page)
"""
import os
import pymupdf as fitz

from ingestion.chunker import chunk_page
from ingestion.sqlite_store import init_db, store_table
from ingestion.index_builder import HybridIndex
from ingestion.page_cache import cached_extract, is_cached

PAGE_IMAGE_DIR = "data/page_images"


def rasterize_pages(pdf_path: str, page_numbers: list, dpi: int = 150) -> dict:
    """1-indexed page_numbers -> saved image paths. Only rasterizes pages
    that don't already have a saved image, so re-running ingestion doesn't
    re-render everything."""
    os.makedirs(PAGE_IMAGE_DIR, exist_ok=True)
    doc = fitz.open(pdf_path)
    paths = {}
    for pn in page_numbers:
        out_path = f"{PAGE_IMAGE_DIR}/page_{pn}.png"
        if not os.path.exists(out_path):
            pix = doc[pn - 1].get_pixmap(dpi=dpi)
            pix.save(out_path)
        paths[pn] = out_path
    return paths


def run_ingestion(pdf_path: str, page_numbers: list, extract_fn, db_path: str = "data/structured_store.db"):
    image_paths = rasterize_pages(pdf_path, page_numbers)
    conn = init_db(db_path)

    all_chunks = []
    for pn in page_numbers:
        if is_cached(pn):
            print(f"page {pn}: using cached extraction (no API call)")
        else:
            print(f"extracting page {pn}...")
        page = cached_extract(extract_fn, image_paths[pn], pn)

        for table in page.tables:
            store_table(conn, page.page_number, page.section_heading, table)

        page_chunks = chunk_page(page)
        all_chunks.extend(page_chunks)
        print(f"  -> {len(page_chunks)} chunks ({sum(1 for c in page_chunks if c.chunk_type=='table_row')} table rows, "
              f"{sum(1 for c in page_chunks if c.chunk_type=='narrative')} narrative)")

    index = HybridIndex()
    index.build_bm25(all_chunks)
    print(f"\nBM25 index built over {len(all_chunks)} chunks total.")
    return index, conn
