"""
Run this once you have a real GEMINI_API_KEY set (see .env.example).
Ingests all 21 pages using the REAL vision_extract.extract_page() -- no mock.

    python run_full_ingest.py

This will make one Gemini call per page (21 calls total). vision_extract.py
already has the same 429-backoff pattern as your agent.py, so free-tier rate
limits are handled, just slowly if you're on the free tier's 15 RPM cap.

Saves the index and structured store to data/ so demo_query.py can load them
without re-running extraction every time.
"""
import os
import sys
from dotenv import load_dotenv

sys.path.insert(0, os.path.dirname(__file__))
load_dotenv()

if not os.getenv("GEMINI_API_KEY"):
    print("ERROR: GEMINI_API_KEY not set. Copy .env.example to .env and add your key.")
    sys.exit(1)

from ingestion.ingest_pipeline import run_ingestion
from ingestion.vision_extract import extract_page  # the REAL Gemini call, not the mock

if __name__ == "__main__":
    pages = list(range(1, 22))  # all 21 pages
    print(f"Running real Gemini vision extraction on {len(pages)} pages...")
    print("(this makes one API call per page -- expect it to take a few minutes on free tier)\n")

    index, conn = run_ingestion(
        "data/SignedCILMoU2019-20.pdf",
        page_numbers=pages,
        extract_fn=extract_page,
    )

    index.save("data/index.pkl")
    print(f"\nDone. Indexed {len(index.chunks)} chunks from {len(pages)} pages.")
    print("Now run: python demo_query.py \"your question\"")
