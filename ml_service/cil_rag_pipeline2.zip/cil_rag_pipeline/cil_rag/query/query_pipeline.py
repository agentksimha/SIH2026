from ingestion.index_builder import HybridIndex
from ingestion.sqlite_store import list_table_schemas, get_rows_for_table
from query.router import route_query, find_matching_table
from query.rrf import reciprocal_rank_fusion


def run_query(query: str, index: HybridIndex, conn, k: int = 5, use_vector: bool = False):
    schemas = list_table_schemas(conn)
    route = route_query(query, schemas)

    if route == "structured":
        table = find_matching_table(query, schemas)
        rows = get_rows_for_table(conn, table["table_id"])
        return {
            "route": "structured",
            "matched_table": table["table_id"],
            "caption": table["caption"],
            "rows": rows,
        }

    # semantic path: BM25 always available; vector search only if embeddings
    # were built (needs network access to the embedding model in this sandbox)
    bm25_results = index.bm25_search(query, k=k)
    if use_vector and index.vectors is not None:
        vector_results = index.vector_search(query, k=k)
        fused = reciprocal_rank_fusion(bm25_results, vector_results)
    else:
        fused = bm25_results  # BM25-only fallback, still exercises the same downstream code

    return {"route": "semantic", "results": fused[:k]}
